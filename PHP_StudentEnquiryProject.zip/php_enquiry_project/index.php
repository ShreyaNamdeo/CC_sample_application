<!DOCTYPE html>
<html>
<head>
    <title>PHP Student Enquiry System</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f0f0f0;
            padding: 40px;
        }
        .container {
            width: 400px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px gray;
        }
        input, textarea {
            width: 100%;
            padding: 8px;
            margin-top: 10px;
        }
        input[type=submit] {
            background-color: green;
            color: white;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Student Enquiry Form</h2>

    <form action="submit.php" method="post">
        Name:
        <input type="text" name="name" required>

        Email:
        <input type="email" name="email" required>

        Message:
        <textarea name="message" rows="5" required></textarea>

        <input type="submit" value="Submit">
    </form>
</div>

</body>
</html>
