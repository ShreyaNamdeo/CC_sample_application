PHP Student Enquiry System

Files:
1. index.php
2. submit.php

How to Run:
1. Install XAMPP
2. Copy project folder into htdocs
3. Start Apache from XAMPP Control Panel
4. Open browser:
   http://localhost/php_enquiry_project

This project is suitable for:
- Mini project demos
- Elastic Beanstalk PHP deployment
- PHP lab experiments
