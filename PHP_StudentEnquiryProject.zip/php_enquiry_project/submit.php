<?php
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Submission Successful</title>
    <style>
        body {
            font-family: Arial;
            background-color: #e8f5e9;
            padding: 40px;
        }
        .box {
            width: 500px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px gray;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>Enquiry Submitted Successfully</h2>

    <p><b>Name:</b> <?php echo $name; ?></p>
    <p><b>Email:</b> <?php echo $email; ?></p>
    <p><b>Message:</b> <?php echo $message; ?></p>

    <br>
    <a href="index.php">Go Back</a>
</div>

</body>
</html>
